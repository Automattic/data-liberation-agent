Portable download fixture
